
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was ufsrvrxlibConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)
find_dependency(uflib)

include("${CMAKE_CURRENT_LIST_DIR}/ufsrvrxlibTargets.cmake")

# Create canonical alias ufsrvrxlib::ufsrvrxlib — resolves to whichever target was built.
# BUILD_SHARED_LIBS=ON  → ufsrvrxlib::ufsrvrxlib_shared (preferred, dynamic linking)
# BUILD_SHARED_LIBS=OFF → ufsrvrxlib::ufsrvrxlib_static
if(NOT TARGET ufsrvrxlib::ufsrvrxlib)
    if(TARGET ufsrvrxlib::ufsrvrxlib_shared)
        add_library(ufsrvrxlib::ufsrvrxlib ALIAS ufsrvrxlib::ufsrvrxlib_shared)
    elseif(TARGET ufsrvrxlib::ufsrvrxlib_static)
        add_library(ufsrvrxlib::ufsrvrxlib ALIAS ufsrvrxlib::ufsrvrxlib_static)
    else()
        message(FATAL_ERROR "Neither ufsrvrxlib::ufsrvrxlib_shared nor ufsrvrxlib::ufsrvrxlib_static found in ufsrvrxlibTargets.cmake")
    endif()
endif()
