#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ufsrvrxlib::ufsrvrxlib_static" for configuration "Release"
set_property(TARGET ufsrvrxlib::ufsrvrxlib_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ufsrvrxlib::ufsrvrxlib_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "ASM;C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libufsrvrxlib.a"
  )

list(APPEND _cmake_import_check_targets ufsrvrxlib::ufsrvrxlib_static )
list(APPEND _cmake_import_check_files_for_ufsrvrxlib::ufsrvrxlib_static "${_IMPORT_PREFIX}/lib/libufsrvrxlib.a" )

# Import target "ufsrvrxlib::ufsrvrxlib_aco" for configuration "Release"
set_property(TARGET ufsrvrxlib::ufsrvrxlib_aco APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ufsrvrxlib::ufsrvrxlib_aco PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "ASM;C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libufsrvrxlib_aco.a"
  )

list(APPEND _cmake_import_check_targets ufsrvrxlib::ufsrvrxlib_aco )
list(APPEND _cmake_import_check_files_for_ufsrvrxlib::ufsrvrxlib_aco "${_IMPORT_PREFIX}/lib/libufsrvrxlib_aco.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
